# Laravel Doctrine Support

Better Doctrine Support with Laravel (Support for `enum`)

# Installing

```
composer require larapack/doctrine-support
```

Then add the following service provider (Laravel 5.4 and below only):

```
Larapack\DoctrineSupport\DoctrineSupportServiceProvider::class
```

Then you are good to go! 🎉

> For Laravel versions older than 5.4.x, use `v0.1.3`.
