<?php

namespace Larapack\Hooks\Exceptions;

class HookAlreadyEnabledException extends HookException
{
    //
}
