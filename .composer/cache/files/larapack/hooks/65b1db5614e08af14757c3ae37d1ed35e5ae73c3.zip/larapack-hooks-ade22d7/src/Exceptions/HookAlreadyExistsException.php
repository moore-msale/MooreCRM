<?php

namespace Larapack\Hooks\Exceptions;

class HookAlreadyExistsException extends HookException
{
    //
}
