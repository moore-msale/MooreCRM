<?php

namespace Larapack\Hooks\Exceptions;

class HookAlreadyInstalledException extends HookException
{
    //
}
