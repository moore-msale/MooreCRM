<?php

namespace Larapack\Hooks\Exceptions;

class HookException extends \Exception
{
    //
}
