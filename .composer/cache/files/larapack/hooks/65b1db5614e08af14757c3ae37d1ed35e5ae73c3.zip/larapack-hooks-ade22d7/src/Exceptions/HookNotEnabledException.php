<?php

namespace Larapack\Hooks\Exceptions;

class HookNotEnabledException extends HookException
{
    //
}
