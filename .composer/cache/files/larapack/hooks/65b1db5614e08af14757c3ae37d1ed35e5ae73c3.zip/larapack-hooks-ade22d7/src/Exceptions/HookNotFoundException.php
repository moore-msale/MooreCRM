<?php

namespace Larapack\Hooks\Exceptions;

class HookNotFoundException extends HookException
{
    //
}
