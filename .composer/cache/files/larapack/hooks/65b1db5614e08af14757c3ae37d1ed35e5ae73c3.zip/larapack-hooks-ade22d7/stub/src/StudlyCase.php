<?php

namespace StudlyCase;

class StudlyCase
{
    //
}
